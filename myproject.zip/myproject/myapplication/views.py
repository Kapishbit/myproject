from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.models import User, auth
from .models import *
import requests
import time
import pytz   #<---------python timezone
import datetime
import calendar



# Create your views here.
# homepage
def index(request):
    return render(request, 'index.html')

#signuppage
def signup(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password1 = request.POST.get('password')
        password2 = request.POST.get('password2')
        if password1 == password2:
            if User.objects.filter(username=username).exists():
                messages.info(request, "username already taken")
                return redirect('signup')
            else:
                user=User.objects.create_user(username=username, password=password1)
                user.save()
                messages.info(request, "user created successfully")
                return redirect('login')
        else:
            messages.info(request, "password doesnt match")
            return redirect('signup')
    else:
        return render(request, 'signup.html')

# login page
def login(request):
    if request.method == 'POST':
        username= request.POST.get('username')
        password= request.POST.get('password')
        user= auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request,user)
            if Fbuser.objects.filter(user=request.user).exists():
                return render(request, 'home.html')
            else:
                return redirect('fbconnect')
        else:
            messages.info(request, "invalid credentials....")
            return redirect('login')
    else:
        return render(request, 'login.html')

# taking input from users
def fbconnect(request):
    if request.method == 'POST':
        accesstoken = request.POST.get('accesstoken')
        pageid = request.POST.get('pageid')
        appid = request.POST.get('appid')
        submit = Fbuser.objects.create(user=request.user, accesstoken=accesstoken, page=pageid, app=appid)
        submit.save()
        messages.info(request, "Submit successfully!")
        return render(request, 'home.html')
    else:
        return render(request, 'fbconnect.html')


# navigation for what the user wants to post(status, photos or videos on different social apps)
def home(request):
    return render(request, 'home.html')


# facebook status publishing(scheduled)
def publish(request):
    if request.method == 'POST':
        caps = request.POST.get('message')
        schld = request.POST.get('sch')
        submit = Facebookmess.objects.create(user=request.user, mess=caps, plan=schld)
        submit.save()
        data = Fbuser.objects.filter(user=request.user)
        context = {'data': data}
        for i in data:
            access_token = i.accesstoken
            page_id = str(i.page)

        data1 = Facebookmess.objects.filter(user=request.user)
        context = {'data': data1}
        for i in data1:
            caps = i.mess
            SCHLD = str(i.plan)
            print(SCHLD)
            x = SCHLD.split(' ')
            print(caps)
            print(x)
            print(x[0])
            print(x[1])
            a = x[0]
            A = a.split('-')
            a1 = A[0]
            a2 = A[1]
            a3 = A[2]
            b = x[1]
            B = b.split(':')
            b1 = B[0]
            b2 = B[1]
            b3 = B[2]
            c = b3.split('+')
            d = c[0]
            date_example = ('{1}/{2}/{0}, {3}:{4}:{5}'.format(a1, a2, a3, b1, b2, d))
            print(date_example)
            date_example1 = str(date_example)
            date_format = datetime.datetime.strptime(date_example1, "%m/%d/%Y, %H:%M:%S")
            user_time = datetime.datetime.timestamp(date_format)
            print(user_time)
            usertime = int(user_time)

            URL = 'https://graph.facebook.com/' + page_id + '/feed?'
            PARAMS = {'published': 'false', 'message': caps, 'scheduled_publish_time': usertime,'access_token': access_token}
            r = requests.post(url=URL, params=PARAMS)
            res = r.json()
            print(res)
            if res['id']:
                messages.info(request, 'Your post is scheduled successfully')
                return render(request, 'home.html')

            else:
                messages.info(request, 'please try again')
                return render(request, 'publish.html')

    else:
        return render(request, 'publish.html')

# facebook image publishing(scheduled)
def fbimg(request):
    if request.method == 'POST':
        caps = request.POST.get('caption')
        img_url = request.POST.get('imgurl')
        schld = request.POST.get('schedule')
        submit =Facebookimg.objects.create(user=request.user, cap=caps, imgurl=img_url, scheduled=schld)
        submit.save()
        data = Fbuser.objects.filter(user=request.user)
        context = {'data': data}
        for i in data:
            access_token = i.accesstoken
            page_id = str(i.page)

        data1 = Facebookimg.objects.filter(user=request.user)
        context = {'data': data1}
        for i in data1:
            IMGURL = i.imgurl
            caps = i.cap
            SCHLD = str(i.scheduled)
            print(IMGURL)
            print(SCHLD)
            x = SCHLD.split(' ')
            print(x)
            print(x[0])
            print(x[1])
            a = x[0]
            A = a.split('-')
            a1 = A[0]
            a2 = A[1]
            a3 = A[2]
            b = x[1]
            B = b.split(':')
            b1 = B[0]
            b2 = B[1]
            b3 = B[2]
            c = b3.split('+')
            d = c[0]
            date_example = ('{1}/{2}/{0}, {3}:{4}:{5}'.format(a1, a2, a3, b1, b2, d))
            print(date_example)
            print('type:', type(date_example).__name__)
            date_example1 = str(date_example)
            date_format = datetime.datetime.strptime(date_example1, "%m/%d/%Y, %H:%M:%S")
            user_time = datetime.datetime.timestamp(date_format)
            print(user_time)
            print('type:',type(user_time).__name__)
            usertime = int(user_time)
            print(usertime)
            print('type:', type(usertime).__name__)
            URL = 'https://graph.facebook.com/'+ page_id + '/photos?'
            PARAMS = {'published':'false','message':caps,'url':IMGURL,'scheduled_publish_time':usertime,'access_token': access_token}
            r = requests.post(url=URL, params=PARAMS)
            res = r.json()
            print(res)
            if res['id']:
                messages.info(request, 'Your post is scheduled successfully')
                return render(request, 'home.html')
            else:
                messages.info(request, 'please try again')
                return render(request, 'fbimg.html')

    else:
        return render(request, 'fbimg.html')

# facebook video publishing(scheduled)
def fbvid(request):
    if request.method == 'POST':
        caps = request.POST.get('capt')
        vidurl = request.POST.get('link')
        schld = request.POST.get('schedule')
        submit =Facebookvid.objects.create(user=request.user, cap1=caps,schld1 = schld ,vid_url = vidurl)
        submit.save()
        data = Fbuser.objects.filter(user=request.user)
        context = {'data': data}
        for i in data:
            access_token = i.accesstoken
            page_id = str(i.page)

        data1 = Facebookvid.objects.filter(user=request.user)
        context = {'data': data1}
        for i in data1:
            VIDURL = i.vid_url
            caps = i.cap1
            SCHLD = str(i.schld1)
            print(VIDURL)
            print(SCHLD)
            print(caps)
            x = SCHLD.split(' ')
            print(x)
            print(x[0])
            print(x[1])
            a = x[0]
            A = a.split('-')
            a1 = A[0]
            a2 = A[1]
            a3 = A[2]
            b = x[1]
            B = b.split(':')
            b1 = B[0]
            b2 = B[1]
            b3 = B[2]
            c = b3.split('+')
            d = c[0]
            date_example = ('{1}/{2}/{0}, {3}:{4}:{5}'.format(a1, a2, a3, b1, b2, d))
            print(date_example)
            date_example1 = str(date_example)
            date_format = datetime.datetime.strptime(date_example1, "%m/%d/%Y, %H:%M:%S")
            user_time = datetime.datetime.timestamp(date_format)
            print(user_time)
            usertime = int(user_time)
            print(usertime)
            URL = 'https://graph.facebook.com/'+ page_id + '/videos?'
            PARAMS = {'published':'false','message':caps,'file_url':VIDURL,'scheduled_publish_time':usertime,'access_token': access_token}
            r = requests.post(url=URL, params=PARAMS)
            res = r.json()
            print(res)
            if res['id']:
                messages.info(request, 'Your post is scheduled successfully')
                return render(request, 'home.html')
            else:
                messages.info(request, 'please try again')
                return render(request, 'fbvid.html')
    else:
        return render(request, 'fbvid.html')

# facebook link publishing(scheduled)
def fblink(request):
    if request.method == 'POST':
        caps = request.POST.get('capts')
        fb_link = request.POST.get('knot')
        schld = request.POST.get('schedule')
        submit = Facebooklink.objects.create(user=request.user, cap2=caps, link_url=fb_link, schld2=schld)
        submit.save()
        data = Fbuser.objects.filter(user=request.user)
        context = {'data': data}
        for i in data:
            access_token = i.accesstoken
            page_id = str(i.page)
            print(page_id)
            print(access_token)
            data1 = Facebooklink.objects.filter(user=request.user)
            context = {'data': data1}
            for i in data1:
                LINKURL = i.link_url
                caps = i.cap2
                SCHLD = str(i.schld2)
                print(LINKURL)
                print(caps)
                print(SCHLD)
                x = SCHLD.split(' ')
                print(caps)
                print(x)
                print(x[0])
                print(x[1])
                a = x[0]
                A = a.split('-')
                a1 = A[0]
                a2 = A[1]
                a3 = A[2]
                b = x[1]
                B = b.split(':')
                b1 = B[0]
                b2 = B[1]
                b3 = B[2]
                c = b3.split('+')
                d = c[0]
                date_example = ('{1}/{2}/{0}, {3}:{4}:{5}'.format(a1, a2, a3, b1, b2, d))
                print(date_example)
                date_example1 = str(date_example)
                date_format = datetime.datetime.strptime(date_example1, "%m/%d/%Y, %H:%M:%S")
                user_time = datetime.datetime.timestamp(date_format)
                print(user_time)
                usertime = int(user_time)
                print(usertime)
                URL = 'https://graph.facebook.com/' + page_id + '/feed?'
                PARAMS = {'published': 'false', 'message': caps, 'link': LINKURL, 'scheduled_publish_time': usertime,
                          'access_token': access_token}
                r = requests.post(url=URL, params=PARAMS)
                res = r.json()
                print(res)
                if res['id']:
                    messages.info(request, 'Your post is scheduled successfully')
                    return render(request, 'home.html')
                else:
                    messages.info(request, 'please try again')
                    return render(request, 'fblink.html')
    else:
        return render(request, 'fblink.html')

# instagram image publishing(scheduled)
def igimg(request):
    if request.POST:
        img_url = request.POST.get('igimg')
        titl= request.POST.get('title')
        print(img_url)
        print(titl)
        data = Fbuser.objects.filter(user=request.user)
        context = {'data': data}
        for i in data:
            access_token = i.accesstoken
            page_id = str(i.page)
            print(page_id)
            print(access_token)
            URL = 'https://graph.facebook.com/v13.0/'+ page_id +'?fields=instagram_business_account'
            PARAMS = { 'access_token': access_token}
            r = requests.get(url=URL, params=PARAMS)
            ig_user_id= r.json()
            print(ig_user_id)
            ig_user_id1 = ig_user_id['instagram_business_account']
            print(ig_user_id1)
            ig_user_id2 = ig_user_id1['id']
            print(ig_user_id2)
            URL1 = 'https://graph.facebook.com/v13.0/'+ig_user_id2+'/media?'
            PARAMETER1 = {'image_url': img_url,'caption': titl , 'access_token': access_token}
            r = requests.post(url=URL1, params=PARAMETER1)
            container_id = r.json()
            print(container_id)
            creation_id = container_id['id']
            URL2 = 'https://graph.facebook.com/v13.0/'+ig_user_id2+'/media_publish?creation_id='+creation_id
            PARAMS = {'access_token': access_token}
            r = requests.post(url=URL2, params=PARAMS)
            res = r.json()
            print(res)

            if res(id):
                return render(request, 'home.html')
                # messages.info(request, 'successfully post')

            else:
                messages.info(request, 'please try again')
                return render(request, 'igimg.html')

    else:
        return render(request, 'igimg.html')

# instagram image publishing(scheduled)
def igvid(request):
    if request.POST:
        vid_url = request.POST.get('vidurl')
        vid_caption = request.POST.get('vidcap')
        data = Fbuser.objects.filter(user=request.user)
        context = {'data': data}
        for i in data:
            access_token = i.accesstoken
            page_id = str(i.page)
            print(page_id)
            print(access_token)
            URL = 'https://graph.facebook.com/v13.0/'+ page_id +'?fields=instagram_business_account'
            PARAMS = {'access_token': access_token}
            r = requests.get(url=URL, params=PARAMS)
            ig_user_id= r.json()
            print(ig_user_id)
            ig_user_id1 = ig_user_id['instagram_business_account']
            print(ig_user_id1)
            ig_user_id2 = ig_user_id1['id']
            print(ig_user_id2)
            URL1 = 'https://graph.facebook.com/v13.0/'+ig_user_id2+'/media?'
            PARAMETER1 = {'video_url': vid_url, 'caption': vid_caption, 'media_type': 'VIDEO', 'access_token':access_token}
            r = requests.post(url=URL1, params=PARAMETER1)
            container_id = r.json()
            print(container_id)
            creation_id1 = container_id['id']
            print(creation_id1)
            url1 = 'https://graph.facebook.com/'+creation_id1+'?fields=status_code&access_token='+access_token
            r = requests.get(url=url1)
            res = r.json()
            print(res)
            res1 = res['status_code']
            print(res1)
            for i in res1:
                url1 = 'https://graph.facebook.com/' + creation_id1 + '?fields=status_code&access_token=' + access_token
                r = requests.get(url=url1)
                res = r.json()
                print(res)
                res1 = res['status_code']
                if res1 == 'FINISHED':
                    URL2 = 'https://graph.facebook.com/v13.0/'+ig_user_id2+'/media_publish?'
                    PARAMS = {'creation_id':creation_id1,'access_token': access_token}
                    r = requests.post(url=URL2, params=PARAMS)
                    res = r.json()
                    print(res)

                    if res(id):
                        return render(request, 'home.html')
                        # messages.info(request, 'successfully post')

                    else:
                        messages.info(request, 'please try again')
                        return render(request, 'igvid.html')

                else:
                    time.sleep(10)
                    continue
    else:
        return render(request, 'igvid.html')

# logout page
def logout(request):
    auth.logout(request)
    return redirect('/')


# saving for future references

# def publish(request):
#     if request.method == 'POST':
#         message = request.POST.get('message')
#         tags = request.POST.get('tags')
#         date_time = request.POST.get('sch')
#         submit = Facebookmess.objects.create(user=request.user, mess=message, plan=date_time)
#         submit.save()
#         data = Fbuser.objects.filter(user=request.user)
#         context = {'data': data}
#         for i in data:
#             access_token=i.accesstoken
#             page_id=str(i.page)
#             app_id=i.app
#         data1 = Facebookmess.objects.filter(user=request.user)
#         context = {'data': data1}
#         for i in data1:
#             mesage = i.mess
#             org = str(i.plan)
#             print(message)
#             print(org)
#             x = org.split(' ')
#             print(x)
#             print(x[0])
#             print(x[1])
#             a = x[0]
#             A = a.split('-')
#             a1 = A[0]
#             a2 = A[1]
#             a3 = A[2]
#             b = x[1]
#             B = b.split(':')
#             b1 = B[0]
#             b2 = B[1]
#             b3 = B[2]
#             c = b3.split('+')
#             d = c[0]
#             date_example1 = ('{2}/{1}/{0}, {3}:{4}:{5}'.format(a1, a2, a3, b1, b2, d))
#             print(date_example1)
#             date_example2 = str(date_example1)
#             print(date_example2)
#             date_format = datetime.datetime.strptime(date_example2, "%m/%d/%Y, %H:%M:%S")
#             user_time = datetime.datetime.timestamp(date_format)
#             print(user_time)
#             print('type:', type(user_time).__name__)
#             usertime = int(user_time)
#             print(usertime)
#             print('type:', type(usertime).__name__)
#             url = 'https://graph.facebook.com/' + page_id + '/feed'
#             if request.method == 'POST':
#                 parameter = {'published':'false','message': mesage,'scheduled_publish_time': usertime, 'access_token': access_token}
#                 r = requests.post(url=url, params=parameter)
#                 postid1 = r.json()
#                 postid2 = postid1['id']
#                 print(postid2)
#
#                 myArray = postid2.split("_")
#                 pageid = myArray[0]
#                 postid = myArray[1]
#                 result = Post.objects.create(user=request.user , pgid=pageid , ptid=postid)
#                 result.save()
#                 if len(postid1):
#                     messages.info(request, 'successfully post')
#                     return render(request, 'home.html')
#                 else:
#                     messages.info(request, 'please try again')
#                     return redirect('publish')
#     else:
#         return render(request, 'publish.html')

# def fbimg(request):
#     if request.POST:
#         data = Fbuser.objects.filter(user=request.user)
#         context = {'data': data}
#         for i in data:
#             access_token = i.accesstoken
#             page_id = str(i.page)
#             print(page_id)
#             print(access_token)
#             URL = 'https://graph.facebook.com/'+ page_id +'/photos? '
#             PARAMS = {'url': 'https://thedigischool.in/wp-content/uploads/2022/04/Digital-marketing-Bootcamp.png',
#                       'access_token': access_token}
#             r = requests.post(url=URL, params=PARAMS)
#             res = r.json()
#             print(res)
#             if len(res):
#                 messages.info(request, 'successfully post')
#                 return render(request, 'fbimg.html')
#
#             else:
#                 messages.error(request, 'please try again')
#     else:
#         return render(request, 'fbimg.html')

# def fbimg(request):
#     if request.method == 'POST':
#         caps = request.POST.get('caption')
#         img_url = request.POST.get('imgurl')
#         schld = request.POST.get('schedule')
#         submit =Facebookimg.objects.create(user=request.user, cap=caps, imgurl=img_url, scheduled=schld)
#         submit.save()
#         data = Fbuser.objects.filter(user=request.user)
#         context = {'data': data}
#         for i in data:
#             access_token = i.accesstoken
#             page_id = str(i.page)
#
#         data1 = Facebookimg.objects.filter(user=request.user)
#         context = {'data': data1}
#         for i in data1:
#             IMGURL = i.imgurl
#             caps = i.cap
#             SCHLD = str(i.scheduled)
#             print(IMGURL)
#             print(SCHLD)
#             x = SCHLD.split(' ')
#             print(x)
#             print(x[0])
#             print(x[1])
#             a = x[0]
#             A = a.split('-')
#             a1 = A[0]
#             a2 = A[1]
#             a3 = A[2]
#             b = x[1]
#             B = b.split(':')
#             b1 = B[0]
#             b2 = B[1]
#             b3 = B[2]
#             c = b3.split('+')
#             d = c[0]
#             date_example = ('{2}/{1}/{0}, {3}:{4}:{5}'.format(a1, a2, a3, b1, b2, d))
#             print(date_example)
#             date_example1 = str(date_example)
#             date_format = datetime.datetime.strptime(date_example1, "%m/%d/%Y, %H:%M:%S")
#             user_time = datetime.datetime.timestamp(date_format)
#             print(user_time)
#             URL = 'https://graph.facebook.com/'+ page_id + '/photos?'
#             PARAMS = {'published':'false','message':caps,'url':IMGURL,'scheduled_publish_time':user_time,'access_token': access_token}
#             r = requests.post(url=URL, params=PARAMS)
#             res = r.json()
#             print(res)
#             if res['id']:
#                 messages.info(request, 'Your post is scheduled successfully')
#                 return render(request, 'home.html')
#
#
#             else:
#                 messages.info(request, 'please try again')
#                 return render(request, 'fbimg.html')
#
#     else:
#         return render(request, 'fbimg.html')

# def publish(request):
#     if request.method == 'POST':
#         access_token = request.POST.get('accesstoken')
#         URL = 'https://graph.facebook.com/100264182669977/feed'
#         PARAMS = {'message':'this  page is posting by Kajal', 'access_token':access_token}
#         r = requests.post(url=URL, params=PARAMS)
#         res = r.json()
#         print(res)
#         messages.info(request,'successfully post')
#         return render(request, 'login.html')

# def fbvid(request):
#     if request.method == 'POST':
#         # caps = request.POST.get('capt')
#         vidurl = request.POST.get('link')
#         # submit = Fbuser.objects.create(user=request.user, cap=caps, imgurl=img_url)
#         # submit.save()
#         data = Fbuser.objects.filter(user=request.user)
#         context = {'data': data}
#         for i in data:
#             access_token = i.accesstoken
#             page_id = str(i.page)
#             print(page_id)
#             print(access_token)
#             print(vidurl)
#             URL = 'https://graph.facebook.com/'+page_id+'/videos?'
#             PARAMS = {'access_token': access_token, 'file_url': vidurl}
#             r = requests.post(url=URL, params=PARAMS)
#             res = r.json()
#             print(res)
#             if len(res):
#                 return render(request, 'home.html')
#                 # messages.info(request, 'successfully post')
#
#             else:
#                 messages.info(request, 'please try again')
#                 return render(request, 'fbvid.html')
#
#     else:
#         return render(request, 'fbvid.html')
#
# def fblink(request):
#     if request.method == 'POST':
#         # caps = request.POST.get('capts')
#         fb_link = request.POST.get('knot')
#         submit = Fbuser.objects.create(user=request.user, cap=caps, imgurl=img_url)
#         submit.save()
#         data = Fbuser.objects.filter(user=request.user)
#         context = {'data': data}
#         for i in data:
#             access_token = i.accesstoken
#             page_id = str(i.page)
#             print(page_id)
#             print(access_token)
#             print(fb_link)
#             URL = 'https://graph.facebook.com/' + page_id + '/feed?'
#             PARAMS = {'link': fb_link, 'access_token': access_token}
#             r = requests.post(url=URL, params=PARAMS)
#             res = r.json()
#             print(res)
#             if len(res):
#                 return render(request, 'home.html')
#                 # messages.info(request, 'successfully post')
#
#             else:
#                 messages.info(request, 'please try again')
#                 return render(request, 'fblink.html')
#
#     else:
#         return render(request, 'fblink.html')

# def fbvid(request):
#     if request.POST:
#         vidurl= request.POST.get('link')
#         access_token='EAAHntjWIGC8BAKLlk0bxI1O8kNMCiebZAEx7gHA5Rdj41PZCvQyH1bwHC8nVCxjLiyZBw21EgFPlSachz7fprk2TH0DFN6Mqw3ZAZCq8UjIhvBJOdVzNMP3QdZBgeZCw0uGKZBUmvmEnU2N6tT77VvxePmuY2TCuZBpL1RDDBA6URVorKWthTPunbQtm9RFLRWrQYnpP6rMEWsGgZCwj1RIbSz'
#         URL = 'https://graph.facebook.com/100264182669977/videos? '
#         PARAMS = {'file_url': vidurl , 'access_token':access_token}
#         r = requests.post(url=URL, params=PARAMS)
#         res = r.json()
#         print(res)
#         if len(res):
#             messages.info(request, 'successfully post')
#             return render(request, 'fbvid.html')
#
#         else:
#             messages.error(request, 'please try again')
#     else:
#         return render(request, 'fbvid.html')




# def fbimg(request):
#     if request.POST:
#         URL = 'https://graph.facebook.com/100264182669977/photos?published=false&message=A scheduled post&scheduled_publish_time=1651666860&access_token=EAAHntjWIGC8BADZAyZAN4b3aj7VzK0v5ZBcLJ48ywPHq1D4NVsHAknARLATSG79SA4qoDr3jepO4B5wnwQGKCFOJiv9aTuXy82UgGMge7J0HSId1Wkx3ZCpZAokWKY0HHpYM0m5sTugWR6OjJFrQnD6M30ifiYMql3KdYHhmOwpKQ8pTN389866yy2CkPUjHTovThMehWOSPqWOGjwmAB&url=https://thedigischool.in/wp-content/uploads/2022/04/Instagramads.png '
#         r = requests.post(url=URL)
#         res = r.json()
#         print(res)
#         if len(res):
#             messages.info(request, 'successfully post')
#             return render(request, 'home.html')
#
#         else:
#             messages.error(request, 'please try again')
#     else:
#         return render(request, 'fbimg.html')






