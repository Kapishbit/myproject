from django.db import models
from django.contrib.auth.models import User
# Create your models here.

# for fb user input
class Fbuser(models.Model):
    # user_id = models.AutoField(primary_key = True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    accesstoken = models.CharField(max_length=250, blank=True)
    page = models.BigIntegerField()
    app = models.BigIntegerField()

    class Meta:
        db_table = 'Fbuser'

    def __str__(self):
        return str(self.page)

#for storing user_id,Page_idand  Post_id

class Post(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    pgid = models.BigIntegerField() #pgid = pageid
    ptid = models.BigIntegerField()  #ptid = postid

    class Meta:
        db_table = 'Post'

    def __str__(self):
        return str(self.user)

class Facebookmess(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    mess = models.CharField(max_length=500)
    plan = models.DateTimeField()

    class Meta:
        db_table = 'Facebookmess'

        def __str__(self):
            return self.user

class Facebookimg(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    cap = models.CharField(max_length=100)
    imgurl = models.URLField(max_length=500)
    scheduled = models.DateTimeField()

    class Meta:
        db_table = 'Facebokimg'

        def __str__(self):
            return self.user

class Facebookvid(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    cap1 = models.CharField(max_length=100)
    vid_url = models.URLField(max_length=500)
    schld1 = models.DateTimeField()

    class Meta:
        db_table = 'Facebookvid'

        def __str__(self):
            return self.user

class Facebooklink(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    cap2 = models.CharField(max_length=100)
    link_url = models.URLField(max_length=500)
    schld2 = models.DateTimeField()

    class Meta:
        db_table = 'Faceboklink'

        def __str__(self):
            return self.user



